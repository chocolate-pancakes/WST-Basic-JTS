extends Area2D

@export var camera: Camera

func _ready() -> void:
	if camera == null:
		printerr("Please set the camera variable in the goal's inspector")


func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		camera.DoneWithFadeIn.connect(EndLevel)
		camera.FadeIn()

func EndLevel() -> void:
	get_tree().change_scene_to_file("res://scenes/world map/world_map.tscn")
