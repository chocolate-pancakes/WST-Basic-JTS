extends Node2D

## What speeds the coin will shoot off at when it's added to the scene
@export var velocity: Vector2 = Vector2.ZERO
## The baseline speed that is mutiplied with the velocity
@export var SPEED = 100.0

func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		call_deferred("queue_free")
		body.coins += 1

func _process(delta: float) -> void:
	position += velocity * delta
	velocity = velocity.move_toward(Vector2.ZERO, delta * 50)
