extends Area2D

class_name CameraTrigger

## The ScrollCamera node
@export var CameraNode: Camera
@export_group("Overrides")
## Sets if the trigger will change the camera's TrackX variable
@export var changeTrackX: bool
## Sets if the trigger will change the camera's TrackY variable
@export var changeTrackY: bool
## Sets if the trigger will change the camera's position
@export var willChangePos: bool
## Sets if the trigger will change the camera's target
@export var willChangeTarget: bool
@export_group("New values")
## The new value for the camera's TrackX variable.[br]
## Ignore if ChangeTrackX is false.
@export var willTrackX: bool
## The new value for the camera's TrackY variable.[br]
## Ignore if ChangeTrackY is false.
@export var willTrackY: bool
## The new value for the camera's position.[br]
## Ignore if WillChangePos is false.
@export var newPos: Vector2
## The new target for the camera to track.[br]
## Ignore if WillChangeTarget is false.
@export var newTarget: Node

func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		if changeTrackX:
			CameraNode.TrackX(willTrackX)
		if changeTrackY:
			CameraNode.TrackY(willTrackY)
		
		if willChangePos:
			CameraNode.SetLocation(newPos)
		
		if willChangeTarget:
			if newTarget is Node:
				CameraNode.ChangeTarget(newTarget)
			else:
				printerr("The camera trigger that was entered was supposed to change the camera's target, but no new target was set in the inspector.")
