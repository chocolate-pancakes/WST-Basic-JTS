extends Node

var currentLevelIndex: int = 1
var newCoinAmount: int
var doLevelUnlock: bool = false

# This script is an autoload, it's loaded at the start of runtime and contains some functions any script can access with Global.method_name
# Please do not attach this script to any node.

func LevelEnd() -> void:
	pass

func LoadLevel(level: PackedScene) -> void:
	get_tree().change_scene_to_packed(level)
