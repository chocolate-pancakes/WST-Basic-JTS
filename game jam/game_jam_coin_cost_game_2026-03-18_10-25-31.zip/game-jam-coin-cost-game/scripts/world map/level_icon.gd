extends Area2D

@export var levelScene: PackedScene

func _process(_delta: float) -> void:
	if Input.is_action_just_pressed("jump") and has_overlapping_bodies():
		get_tree().change_scene_to_packed(levelScene)
