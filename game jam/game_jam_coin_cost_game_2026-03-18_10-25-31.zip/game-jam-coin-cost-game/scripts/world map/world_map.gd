extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$Map.scale = Vector2(1, 1)
	$Map/AnimationPlayer.play("intro")
	$Traveler.hide()
	$Traveler/Sprite.play()


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	var movement = Input.get_vector("move_left", "move_right", "move_up", "move_down")
	
	$Traveler.velocity = movement * 200
	if movement:
		$Traveler/Sprite.animation = "walk"
	else:
		$Traveler/Sprite.animation = "idle"
	if movement.x > 0:
		$Traveler/Sprite.flip_h = false
	elif movement.x < 0:
		$Traveler/Sprite.flip_h = true
	
	$Traveler.move_and_slide()

func _on_animation_player_animation_finished(_anim_name: StringName) -> void:
	$ScrollCamera.ChangeTarget($Traveler)
	$ScrollCamera.TrackX()
	$ScrollCamera.TrackY()
	$ScrollCamera.position_smoothing_enabled = true
	
	$Traveler.show()
