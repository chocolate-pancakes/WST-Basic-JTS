extends Node

func _physics_process(_delta: float) -> void:
	if Input.is_action_just_pressed("attack"):
		FireBullet(deg_to_rad(0) if !get_parent().get_child(0).flip_h else deg_to_rad(180))
	
	if Input.is_action_just_pressed("alt_attack") and !get_parent().is_on_floor():
		FireBullet(deg_to_rad(90))

func FireBullet(angle: float) -> void:
	if $FireCooldown.is_stopped() and get_parent().coins > 0:
		var newBullet = get_parent().bulletScene.instantiate()
		add_child(newBullet)
		
		newBullet.top_level = true
		newBullet.position = get_parent().position
		newBullet.rotation = angle
		
		get_parent().LoseCoins(1, false)
		$FireCooldown.start()
