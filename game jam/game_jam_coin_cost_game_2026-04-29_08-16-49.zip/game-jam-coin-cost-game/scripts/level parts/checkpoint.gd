extends Area2D

var isActive: bool = false

func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		if !isActive:
			$AnimatedSprite2D.play("activate")
			isActive = true

func _on_animated_sprite_2d_animation_finished() -> void:
	$AnimatedSprite2D.play("on")
