extends Node

var currentLevelIndex: int = 1
var newCoinAmount: int
var doLevelUnlock: bool = false
var totalLoss: int = 0

var textColor = Color("ffffff")
var selectColor = Color("ffff00")

# This script is an autoload, it's loaded at the start of runtime and contains some functions and variables any script can access with Global.attribute_name
# Please do not attach this script to any node.

func LevelEnd() -> void:
	doLevelUnlock = true
	currentLevelIndex = 1
	get_tree().change_scene_to_file("res://scenes/world map/world_map.tscn")

func LoadLevel(level: PackedScene) -> void:
	get_tree().change_scene_to_packed(level)

func _ready() -> void:
	var windowModes = [Window.MODE_WINDOWED, Window.MODE_MAXIMIZED, Window.MODE_EXCLUSIVE_FULLSCREEN, Window.MODE_FULLSCREEN]
	DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_SHARP_CORNERS, true)
	var settingsFile = ConfigFile.new()
	settingsFile.load("user://settings.sav")
	
	var musicVolume = settingsFile.get_value("Settings", "Music Volume", 10)
	var SFXVolume = settingsFile.get_value("Settings", "SFX Volume", 10)
	var currentWindowMode = settingsFile.get_value("Settings", "Window mode", 0)
	
	AudioServer.set_bus_volume_linear(1, float(musicVolume) / 10)
	AudioServer.set_bus_volume_linear(2, float(SFXVolume) / 10)
	DisplayServer.window_set_mode(windowModes[currentWindowMode])
