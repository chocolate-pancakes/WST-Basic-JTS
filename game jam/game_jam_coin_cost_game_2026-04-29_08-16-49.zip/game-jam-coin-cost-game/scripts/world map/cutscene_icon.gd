extends Area2D

## The level this icon leads to
@export var levelScene: PackedScene
## The index of the level, this one starts from 1, by the way
@export var levelOrder: int = 1
## Name of the level
@export var levelName: String
## The cost of the level to buy
@export var levelCost: int = 0
var rootMap

var isUnlocked: bool = false
var isBought: bool = false
var playerTouching: bool = false

var isCutscene = true

func _ready() -> void:
	rootMap = get_parent().get_parent()
	$AnimatedSprite2D.play("unbeaten")
	

func _process(_delta: float) -> void:
	if has_overlapping_bodies():
		rootMap.callLevelUI.emit(self, true)
		playerTouching = true
		if isBought:
			if Input.is_action_just_pressed("jump"):
				rootMap.StartLevel(levelScene, self)
		elif isUnlocked:
			if Input.is_action_just_pressed("jump") and rootMap.coins >= levelCost:
				rootMap.coins -= levelCost
				$AnimatedSprite2D.play("filling")
				rootMap.boughtLevelAmount = levelOrder
				isBought = true
				rootMap.Save()
	
	if !has_overlapping_bodies() and playerTouching:
		playerTouching = false
		rootMap.callLevelUI.emit(self, false)

func _on_world_map_prep() -> void:
	isUnlocked = rootMap.unlockedLevelAmount >= levelOrder
	isBought = true
	if isBought:
		$AnimatedSprite2D.play("beaten")
	else:
		$AnimatedSprite2D.play("unbeaten")
