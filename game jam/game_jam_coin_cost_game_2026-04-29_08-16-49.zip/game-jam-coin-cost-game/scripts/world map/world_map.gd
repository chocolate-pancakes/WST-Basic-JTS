extends Node2D
signal prep
signal callLevelUI

# Reference to save files
# levels.sav - Unlocked levels
# game.sav - Total coin amounts/game flags
# items.sav - Bought/equipped items
# settings.sav - Game settings

var unlockedLevelAmount: int = 1
var boughtLevelAmount: int = 0
var coins: int = 110
var level
var levelSpots: Array

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	SetSpotArray()
	LoadUnlockedLevels()
	LoadGame(!Global.doLevelUnlock)
	if Global.doLevelUnlock:
		if unlockedLevelAmount < Global.currentLevelIndex + 1:
			unlockedLevelAmount = Global.currentLevelIndex + 1
		
		$Traveler.position = levelSpots[Global.currentLevelIndex - 1].position
		$Traveler.position.y -= 50
		
		coins = Global.newCoinAmount
		Save()
	prep.emit()
	
	$Map.scale = Vector2(1, 1)
	$Map/AnimationPlayer.play("intro")
	$Traveler.hide()
	$Traveler/Sprite.play()

func _process(_delta: float) -> void:
	var movement = Input.get_vector("move_left", "move_right", "move_up", "move_down") if !get_tree().paused else Vector2.ZERO
	
	$Traveler.velocity = movement * 200
	if movement:
		$Traveler/Sprite.animation = "walk"
	else:
		$Traveler/Sprite.animation = "idle"
	if movement.x > 0:
		$Traveler/Sprite.flip_h = false
	elif movement.x < 0:
		$Traveler/Sprite.flip_h = true
	
	$Traveler.move_and_slide()
	
	$WorldMapUi/CoinCounter.text = "Coins: " + str(coins)

func _on_animation_player_animation_finished(_anim_name: StringName) -> void:
	$ScrollCamera.ChangeTarget($Traveler)
	$ScrollCamera.TrackX()
	$ScrollCamera.TrackY()
	$ScrollCamera.position_smoothing_enabled = true
	
	$Traveler.show()
	$WorldMapUi/AnimationPlayer.play("counterAppear")
	$WorldMapUi.okToAnimate = true

func LoadUnlockedLevels() -> void:
	var levelUnlocks = ConfigFile.new()
	var err = levelUnlocks.load("user://levels.sav")
	
	if err != OK:
		# The load function in a ConfigFile both acts as a function and returns a value. If the file is present and loaded, it returns OK.
		# If the file isn't there, it returns an error, and this if loop will quit out of the function before it reads values from the file.
		return
	
	unlockedLevelAmount = levelUnlocks.get_value("Levels", "Amount")
	boughtLevelAmount = levelUnlocks.get_value("Levels", "Bought")

func LoadGame(skipLoadLoss: bool) -> void:
	var gameFile = ConfigFile.new()
	var err = gameFile.load("user://game.sav")
	
	if err != OK:
		return
	
	coins = gameFile.get_value("Game", "Coins")
	if skipLoadLoss:
		Global.totalLoss = gameFile.get_value("Game", "TotalLoss")

func Save() -> void:
	var levelFile = ConfigFile.new()
	var progressFile = ConfigFile.new()
	var itemFile = ConfigFile.new()
	
	levelFile.set_value("Levels", "Amount", unlockedLevelAmount)
	levelFile.set_value("Levels", "Bought", boughtLevelAmount)
	levelFile.save("user://levels.sav")
	
	progressFile.set_value("Game", "Coins", coins)
	progressFile.set_value("Game", "TotalLoss", Global.totalLoss)
	progressFile.save("user://game.sav")
	
	itemFile.save("user://items.sav")

func DontCall():
	## This purely exists to set some stuff up with signals. DO NOT CALL THIS FUNCTION
	if false:
		callLevelUI.emit(self, true)

func StartLevel(levelLoad: PackedScene, icon: Area2D) -> void:
	$ScrollCamera.FadeIn()
	level = levelLoad
	Global.currentLevelIndex = icon.levelOrder
	$WorldMapUi.okToAnimate = false
	$WorldMapUi/AnimationPlayer.play("counterDisappear")

func _on_scroll_camera_done_with_fade_in() -> void:
	Global.LoadLevel(level)

func SetSpotArray() -> void:
	levelSpots = $"Level Spots".get_children()
