extends Node2D

@export var velocity: Vector2 = Vector2.ZERO
@export var SPEED = 100.0

func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		call_deferred("queue_free")
		body.coins += 1

func _process(delta: float) -> void:
	position += velocity * delta
	velocity = velocity.move_toward(Vector2.ZERO, delta * 50)
