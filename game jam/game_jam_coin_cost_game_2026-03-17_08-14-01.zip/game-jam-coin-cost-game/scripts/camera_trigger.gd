extends Area2D

class_name CameraTrigger

@export var CameraNode: Camera
@export_group("Overrides")
@export var changeTrackX: bool
@export var changeTrackY: bool
@export var willChangePos: bool
@export var willChangeTarget: bool
@export_group("New values")
@export var willTrackX: bool
@export var willTrackY: bool
@export var newPos: Vector2
@export var newTarget: Node

func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		if changeTrackX:
			CameraNode.TrackX(willTrackX)
		if changeTrackY:
			CameraNode.TrackY(willTrackY)
		
		if willChangePos:
			CameraNode.SetLocation(newPos)
		
		if willChangeTarget:
			if newTarget is Node:
				CameraNode.ChangeTarget(newTarget)
			else:
				printerr("The camera trigger that was entered was supposed to change the camera's target, but no new target was set in the inspector.")
