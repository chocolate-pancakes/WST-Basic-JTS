extends Area2D

class_name Bullet

@export var speed: Vector2 = Vector2(450, 0)
@export var isEvil: bool = false

func _physics_process(delta: float) -> void:
	position += speed.rotated(rotation) * delta

func _on_body_entered(body: Node2D) -> void:
	if isEvil:
		if body is Player:
			call_deferred("queue_free")
	else:
		if body is not Player:
			call_deferred("queue_free")

func _on_visible_on_screen_notifier_2d_screen_exited() -> void:
	# If a bullet is no longer visible, probably best to get rid of it.
	call_deferred("queue_free")
