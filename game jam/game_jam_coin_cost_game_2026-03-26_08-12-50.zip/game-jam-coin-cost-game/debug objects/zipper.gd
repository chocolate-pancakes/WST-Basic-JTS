extends Area2D

@export var destination: Node2D

func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		body.position = destination.position
