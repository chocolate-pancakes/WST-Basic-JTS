extends Area2D

@export var bulletScene: PackedScene
@export var coinScene: PackedScene
var health: int = 3
@export var lookingLeft = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	$AnimatedSprite2D.flip_h = lookingLeft

func _on_area_entered(area: Area2D) -> void:
	if area is Bullet:
		if !area.isEvil:
			health -= 1
			if health == 0:
				$DeathFX.restart()
				$AnimatedSprite2D.hide()
				
				set_deferred("monitoring", false)
				set_deferred("monitorable", false)
				
				set_collision_layer_value(1, false)
				
				$Timer.paused = true
				
				var newCoin = coinScene.instantiate()
				get_node("/root").call_deferred("add_child", newCoin)
				newCoin.top_level = true
				newCoin.position = position
				newCoin.velocity = Vector2(0, -40)

func _on_death_fx_finished() -> void:
	call_deferred("queue_free")


func _on_timer_timeout() -> void:
	if $VisibleOnScreenNotifier2D.is_on_screen():
		var newCoin = bulletScene.instantiate()
		get_node("/root").call_deferred("add_child", newCoin)
		newCoin.top_level = true
		newCoin.position = position
		newCoin.z_index = -1
		newCoin.isEvil = true
		newCoin.speed = Vector2(250, 0) * (-1 if lookingLeft else 1)
		$AnimatedSprite2D.play("fire")
