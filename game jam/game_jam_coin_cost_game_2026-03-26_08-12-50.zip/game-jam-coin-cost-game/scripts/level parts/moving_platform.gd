extends AnimatableBody2D

@export var Speed: float = 10
@export var path: Path2D
@export var bounce: bool = false
var PointIndex: int = 0
var direction: int = 1

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	position = path.curve.get_point_position(0)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _physics_process(_delta: float) -> void:
	position = position.move_toward(path.curve.get_point_position(PointIndex), Speed)
	if position == path.curve.get_point_position(PointIndex):
		PointIndex += direction
		if PointIndex >= path.curve.point_count:
			if bounce:
				PointIndex = path.curve.point_count -2
				FlipDir()
			else:
				PointIndex = 0
		if PointIndex == -1:
			PointIndex = 0
			FlipDir()

func FlipDir() -> void:
	direction = -direction
