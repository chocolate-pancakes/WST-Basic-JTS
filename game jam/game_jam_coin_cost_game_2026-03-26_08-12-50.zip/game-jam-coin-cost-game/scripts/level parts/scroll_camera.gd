extends Camera2D


class_name Camera

signal DoneWithFadeIn
signal DoneWithFadeOut

@export var target: Node
@export var isTrackingX: bool = true
@export var isTrackingY: bool = true
@export var startWithFade: bool = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if target == null and (isTrackingX or isTrackingY):
		# Sends an error to the output if you didn't set the target in the inspector.
		printerr("The camera for the currently loaded scene has no target set in the inspector.")
		TrackX(false)
		TrackY(false)
	else:
		if isTrackingX:
			position.x = target.position.x
		if isTrackingY:
			position.y = target.position.y
	if startWithFade:
		FadeOut()

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	if isTrackingX:
		position.x = target.position.x
	if isTrackingY:
		position.y = target.position.y

func SnapToTarget() -> void:
	## Turns off the position smoothing to instantly jump to the target
	position_smoothing_enabled = false
	position = target.position
	position_smoothing_enabled = true

func ChangeTarget(newTarget: Node) -> void:
	## Changes the camera's target
	target = newTarget

func TrackX(track: bool = true) -> void:
	isTrackingX = track

func TrackY(track: bool = true) -> void:
	isTrackingY = track

func SetLocation(newPosition: Vector2) -> void:
	if !isTrackingX:
		position.x = newPosition.x
	if !isTrackingY:
		position.y = newPosition.y

func FadeIn() -> void:
	$ColorRect/AnimationPlayer.play("fade_in")

func FadeOut() -> void:
	$ColorRect/AnimationPlayer.play("fade_out")

func _on_animation_player_animation_finished(anim_name: StringName) -> void:
	if anim_name == "fade_in":
		DoneWithFadeIn.emit()
	if anim_name == "fade_out":
		DoneWithFadeOut.emit()
