extends Area2D

@export var levelScene: PackedScene
@export var levelOrder: int = 1
@export var levelName: String
@export var levelCost: int = 50
var rootMap

var isUnlocked: bool = false
var isBought: bool = false
var playerTouching: bool = false

func _ready() -> void:
	rootMap = get_tree().root.get_child(0)
	$AnimatedSprite2D.play("unbeaten")

func _process(_delta: float) -> void:
	if has_overlapping_bodies():
		rootMap.callLevelUI.emit(self, true)
		playerTouching = true
		if isBought:
			if Input.is_action_just_pressed("jump"):
				get_node("/root").get_child(0).StartLevel(levelScene)
		elif isUnlocked:
			if Input.is_action_just_pressed("jump") and rootMap.coins >= levelCost:
				rootMap.coins -= levelCost
				$AnimatedSprite2D.play("filling")
				rootMap.boughtLevelAmount = levelOrder
				isBought = true
				rootMap.Save()
	
	if !has_overlapping_bodies() and playerTouching:
		playerTouching = false
		rootMap.callLevelUI.emit(self, false)

func _on_world_map_prep() -> void:
	isUnlocked = rootMap.unlockedLevelAmount >= levelOrder
	isBought = rootMap.boughtLevelAmount >= levelOrder
	if isBought:
		$AnimatedSprite2D.play("beaten")
	else:
		$AnimatedSprite2D.play("unbeaten")
