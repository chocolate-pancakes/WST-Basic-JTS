extends CharacterBody2D

# class_name gives the node the script is attach to a unique identifier any script can acess, think how you can set a variable's type to a script name in Unity
class_name Player

# Remember: @export is GDScript's [Serializefield]
# @export_group also places each variable under it in a nice, collapsable section in the inspector
# PS you don't always have to tell Godot what type a variable is, but if you have an @export and don't have an initial value Godot will get mad at you
# and even if it's not an @export, I think if you try adding stuff to an uninitialized variable, Godot will throw an error for trying to add to a nil value
@export_group("Movement")
@export var SPEED = 200.0
@export var JUMP_VELOCITY = -400.0
@export var coinDroughtSlowness: float = 0.75
@export_group("Coin losses")
@export var walkLoss: int
@export var jumpLoss: int
@export_group("Scene references (maybe don't touch these)")
@export var bulletScene: PackedScene

var coins: int = 500
var holding_jump: bool = false
var startPos: Vector2

var shouldFlip: bool = false
var overrideControls: bool = false

func _ready() -> void:
	startPos = position
	$AnimatedSprite2D.play()
	
	var gameFile = ConfigFile.new()
	gameFile.load("user://game.sav")
	
	coins = gameFile.get_value("Game", "Coins")

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
	
	# Handle jump.
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y += JUMP_VELOCITY
		holding_jump = true
		LoseCoins(jumpLoss, true)
	if holding_jump and velocity.y < 0:
		velocity.y -= 15

	# Get the input direction and handle the movement/deceleration.
	if !overrideControls:
		var direction = Input.get_axis("move_left", "move_right")
		if direction:
			# Sets the velocity, flips the sprite and particle direction if needed, then starts the WalkCoinLose timer if it isn't already running
			velocity.x = direction * SPEED * (1.0 if coins > 0 else coinDroughtSlowness)
			SetFXAndSpriteFlip(direction)
			if $WalkCoinLose.is_stopped(): $WalkCoinLose.start()
		else:
			# Move the x velocity towards 0, and stop the WalkCoinLoseTimer
			velocity.x = move_toward(velocity.x, 0, SPEED / 3)
			$WalkCoinLose.stop()
	
	# move_and_slide() is a built-in function for CharacterBody2Ds that has it perform physics
	move_and_slide()
	HandleAnimation()
	
	if is_on_floor():
		overrideControls = false
	
	for i in get_slide_collision_count():
		var collider = get_slide_collision(i)
		if collider.get_collider().is_in_group("Enemy"):
			Hurt(collider.get_collider())


func _process(_delta: float) -> void:
	# Just makes it so when the jump button is released, holding_jump is false
	if Input.is_action_just_released("jump"):
		holding_jump = false
	if Input.is_action_just_pressed("resest"):
		position = startPos
	
	if position.y > 848.0:
		position = startPos
		LoseCoins(10)

func _on_walk_coin_lose_timeout() -> void:
	# The WalkCoinLose child node calls this function every time it finishes
	LoseCoins(walkLoss)

func LoseCoins(loss: int, doEffect: bool = true) -> void:
	if coins > 0:
		coins -= loss
		if doEffect:
			if !$CoinFX1.emitting:
				$CoinFX1.amount = loss
				$CoinFX1.restart()
			elif !$CoinFX2.emitting:
				$CoinFX2.amount = loss
				$CoinFX2.restart()
			else:
				$CoinFX3.amount = loss
				$CoinFX3.restart()

func SetFXAndSpriteFlip(direction: float) -> void:
	# This isn't just shouldFlip = direction < 0 since the sprite needs to stay whatever direction it was facing when you stop moving
	if direction > 0:
		shouldFlip = false
	if direction < 0:
		shouldFlip = true
	
	$AnimatedSprite2D.flip_h = shouldFlip
	# Flips the CoinFX to face the opposite way as well
	$CoinFX1.direction = Vector2(-1, -1) if !shouldFlip else Vector2(1, -1)
	$CoinFX2.direction = Vector2(-1, -1) if !shouldFlip else Vector2(1, -1)
	$CoinFX3.direction = Vector2(-1, -1) if !shouldFlip else Vector2(1, -1)
	# Yes, Godot will let you put if then statements in values

func HandleAnimation() -> void:
	var currentlyFiring = !$BulletHandler/FireCooldown.is_stopped()
	if currentlyFiring:
		currentlyFiring = "_fire"
	else:
		currentlyFiring = ""
	
	if overrideControls:
		$AnimatedSprite2D.animation = "hurt"
	elif !is_on_floor():
		$AnimatedSprite2D.animation = "jump" + currentlyFiring
	elif Input.get_axis("move_left", "move_right"):
		$AnimatedSprite2D.animation = "walk" + currentlyFiring
	else:
		$AnimatedSprite2D.animation = "idle" + currentlyFiring

func Hurt(enemy: Node2D) -> void:
	if $IFrame.is_stopped():
		velocity.y = JUMP_VELOCITY
		var knockbackDir = 1 if position > enemy.position else -1
		velocity.x = SPEED * knockbackDir
		overrideControls = true
		LoseCoins(10)
		$IFrame.start()
