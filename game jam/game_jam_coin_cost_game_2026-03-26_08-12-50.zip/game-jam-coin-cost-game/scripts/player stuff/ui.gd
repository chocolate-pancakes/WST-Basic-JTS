extends CanvasLayer

@export var playerNode: Player
@export var camera: Camera

@onready var resume = $Panel/ResumeText
@onready var restart = $Panel/RestartText
@onready var exit = $Panel/ExitText

var menuSelection: int = 1

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	if camera == null:
		printerr("Please set the camera variable for the UI in the inspector.")
	if playerNode == null:
		printerr("Please set the playerNode variable for the UI in the inspector.")


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	$CoinCounter.text = "Coins: " + str(playerNode.coins)
	if Input.is_action_just_pressed("pause"):
		get_tree().paused = !get_tree().paused
		if get_tree().paused:
			menuSelection = 1
			$AnimationPlayer.play("pause")
		else:
			$AnimationPlayer.play("unpause")
	
	if get_tree().paused:
		match menuSelection:
			1:
				resume.add_theme_color_override("font_color", Color("#ffff00"))
				restart.add_theme_color_override("font_color", Color("#ffffff"))
				exit.add_theme_color_override("font_color", Color("#ffffff"))
			2:
				resume.add_theme_color_override("font_color", Color("#ffffff"))
				restart.add_theme_color_override("font_color", Color("#ffff00"))
				exit.add_theme_color_override("font_color", Color("#ffffff"))
			3:
				resume.add_theme_color_override("font_color", Color("#ffffff"))
				restart.add_theme_color_override("font_color", Color("#ffffff"))
				exit.add_theme_color_override("font_color", Color("#ffff00"))
		
		if Input.is_action_just_pressed("move_down"):
			menuSelection += 1
			if menuSelection > 3:
				menuSelection = 1
		if Input.is_action_just_pressed("move_up"):
			menuSelection -= 1
			if menuSelection < 0:
				menuSelection = 3
		
		if Input.is_action_just_pressed("jump"):
			match menuSelection:
				1:
					Unpause()
				2:
					camera.DoneWithFadeIn.connect(RestartLevel)
					camera.FadeIn()
					Unpause()
				3:
					camera.DoneWithFadeIn.connect(ExitLevel)
					camera.FadeIn()
					Unpause()

func RestartLevel() -> void:
	get_tree().reload_current_scene()

func ExitLevel() -> void:
	get_tree().call_deferred("unload_current_scene")
	get_tree().change_scene_to_file("res://scenes/world map/world_map.tscn")

func Unpause() -> void:
	$AnimationPlayer.play("unpause")
	get_tree().paused = false
