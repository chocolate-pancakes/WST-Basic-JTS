extends Area2D

signal LevelOver

## The camera node in the scene
@export var camera: Camera
## The UI node in the scene
@export var UI: CanvasLayer

var player: Player

func _ready() -> void:
	if camera == null:
		printerr("Please set the camera variable in the goal's inspector")
	if UI == null:
		printerr("Please set the UI variable in the goal's inspector")
	else:
		LevelOver.connect(UI.WinLevelUI)

func _process(_delta: float) -> void:
	if $AnimatedSprite2D.frame == 5:
		$ShatterSFX.play()

func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		player = body
		body.overrideControls = true
		$AnimatedSprite2D.play("shatter")
		
		var direction = 1 if player.position.x > position.x else -1
		
		player.overrideAnimation = true
		player.slipAround = true
		player.velocity = Vector2(200 * direction, -500)
		player.onLanding.connect(StopPlayer)
		player.ChangeMusic()
		
		camera.TrackX(false)
		camera.TrackY(false)
		
		player.PlayAnimation("idle_fire")

func EndLevel() -> void:
	Global.doLevelUnlock = true
	
	get_tree().change_scene_to_file("res://scenes/world map/world_map.tscn")
	Global.newCoinAmount = player.coins

func _on_animated_sprite_2d_animation_finished() -> void:
	LevelOver.emit(self)
	camera.DoneWithFadeIn.connect(EndLevel)
	$WinSFX.play()

func StopPlayer() -> void:
	player.velocity = Vector2.ZERO
	player.PlayAnimation("put_away")
