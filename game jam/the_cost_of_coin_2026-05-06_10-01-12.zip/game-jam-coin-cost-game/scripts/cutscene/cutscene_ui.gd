extends CanvasLayer

## Keyframe this in the AnimationPlayer.[br]
## Name of the person who is curently talking. Set before you display.
@export var activeSpeaker: String
## Keyframe this in the AnimationPlayer.[br]
## The current dialogue that's being said. Set before you display.
@export var dialogue: String
## Keyframe this in the AnimationPlayer.[br]
## Set this to [code]true[/code] when you want to display dialogue. The cutscene will imediately be paused and this will be set back to [code]false[/code].
@export var displayDialogue: bool
## Keyframe this in the AnimationPlayer.[br]
## Set this to [code]true[/code] when the cutscene finishes. It will instantly go back to the world map.
@export var finishCutscene: bool


## Set this to the AnimationPlayer that's controlling the cutscene.
@export var animPlayer: AnimationPlayer

@onready var speakerText: Label = $Control/Speaker
@onready var dialogueText: Label = $Control/Dialogue

var isWaiting: bool = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	ClearText()

func _process(_delta: float) -> void:
	if displayDialogue:
		animPlayer.pause()
		speakerText.text = activeSpeaker
		dialogueText.text = dialogue
		displayDialogue = false
		isWaiting = true
	if isWaiting:
		if Input.is_action_just_pressed("jump"):
			ClearText()
			animPlayer.play()
			isWaiting = false
	
	if finishCutscene:
		Global.leftCutscene = true
		get_tree().change_scene_to_file("res://scenes/world map/world_map.tscn")

func ClearText() -> void:
	speakerText.text = ""
	dialogueText.text = ""
