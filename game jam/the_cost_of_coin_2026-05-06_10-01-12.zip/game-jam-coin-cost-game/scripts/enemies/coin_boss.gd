extends CharacterBody2D

@export var player: Player
@export var health: int = 15
@export var coinScene: PackedScene
@export var sceneAnimPlayer: AnimationPlayer

var direction: int = 1
var areialLastFrame: bool
var prepping: bool = false
var queuedCoins: int = 0
var dead: bool = false
var passProcess: bool = true

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$Timer.start(randf_range(1.5, 3.5))
	$AnimatedSprite2D.speed_scale = 0

func _physics_process(delta: float) -> void:
	if !passProcess:
		if !dead:
			FacePlayer()
			if !prepping:
				velocity.x += direction * 5
				$AnimatedSprite2D.speed_scale = velocity.x / 100
			elif prepping and $AnimatedSprite2D.animation == "jump_prep" or $AnimatedSprite2D.animation == "spray":
				velocity.x = 0
			if not is_on_floor():
				velocity += get_gravity() * delta
			
			Skid()
			HandleLandingStop()
		else:
			if queuedCoins == 0:
				position = position.move_toward(Vector2(640, -1), 1)
			if position == Vector2(640, -1):
				$AnimatedSprite2D.speed_scale = 1
				sceneAnimPlayer.play("win")
				passProcess = true
		move_and_slide()
	
	if Input.is_action_just_pressed("debug_key1"):
		health = 1
		Hurt()

func _on_area_2d_area_entered(area: Area2D) -> void:
	if area.is_in_group("DeathBarrier"):
		position.x -= 100 * direction
		$AnimatedSprite2D.play("jump")
		velocity = Vector2(500 * direction, -1200)

func FacePlayer() -> void:
	if player.position.x > position.x:
		direction = 1
		$AnimatedSprite2D.flip_h = false
	else:
		direction = -1
		$AnimatedSprite2D.flip_h = true

func _on_timer_timeout() -> void:
	$AnimatedSprite2D.speed_scale = 1
	$Timer.start(randf_range(1.5, 3.5))
	if !is_on_floor():
		return
	prepping = true
	$AnimatedSprite2D.play("jump_prep")

func HandleLandingStop() -> void:
	if !is_on_floor():
		areialLastFrame = true
	if is_on_floor() and areialLastFrame:
		areialLastFrame = false
		prepping = false
		velocity = Vector2.ZERO
		$AnimatedSprite2D.animation = "default"

func _on_animated_sprite_2d_animation_finished() -> void:
	if $AnimatedSprite2D.animation == "jump_prep":
		$AnimatedSprite2D.play("jump")
		velocity.x = 350 * direction
		velocity.y = -600
	if $AnimatedSprite2D.animation == "spray":
		prepping = false
		$AnimatedSprite2D.play("default")

func _on_drop_timer_timeout() -> void:
	if queuedCoins > 0:
		queuedCoins -= 1
		var newCoin = coinScene.instantiate()
		get_node("/root").get_child(1).call_deferred("add_child", newCoin)
		newCoin.top_level = true
		newCoin.position = position
		newCoin.velocity = Vector2(randi_range(-120, 110) + 10, randi_range(-40, 20) + 10)

func Death() -> void:
	position.y -= 10
	velocity = Vector2.ZERO
	$DropTimer.wait_time = 0.05
	$Timer.timeout.disconnect(_on_timer_timeout)
	$AnimatedSprite2D.play("death")
	$AnimatedSprite2D.speed_scale = 0
	$CollisionShape2D.call_deferred("queue_free")
	
	player.ChangeMusic()
	
	queuedCoins = 100
	dead = true

func _on_animation_player_animation_finished(anim_name: StringName) -> void:
	if anim_name == "death":
		call_deferred("queue_free")

func _on_wait_timer_timeout() -> void:
	passProcess = false

func Skid() -> void:
	if is_on_floor():
		if player.position.x > position.x:
			if velocity.x > 10:
				$SkidTimer.start()
		if player.position.x < position.x:
			if velocity.x < 10:
				$SkidTimer.start()

func _on_skid_timer_timeout() -> void:
	velocity.x = velocity.x * direction

func _on_player_checker_body_entered(body: Node2D) -> void:
	if body is Player and !dead:
		body.Hurt(self)
		$AnimatedSprite2D.play("jump")
		position.y -= 10
		velocity.x = 350 * direction
		velocity.y = -600

func Hurt() -> void:
	if !$AnimationPlayer.is_playing():
		$AnimationPlayer.play("hit")
		health -= 1
		
		var newCoin = coinScene.instantiate()
		get_node("/root").get_child(1).call_deferred("add_child", newCoin)
		newCoin.top_level = true
		newCoin.position = position
		newCoin.velocity = Vector2(0, -40)
		queuedCoins += 9
		
		if health == 0:
			$Area2D.call_deferred("queue_free")
			Death()
