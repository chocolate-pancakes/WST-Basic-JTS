extends CharacterBody2D


@export var SPEED = 750.0
@export var health: int = 3
@export var direction = 1
@export var coinScene: PackedScene

func _ready() -> void:
	$AnimatedSprite2D.play()

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta
	
	if is_on_floor() and !$RayCast2D.is_colliding():
		if $RayCast2D.get_collider() is not Player:
			Flip()
	
	if is_on_wall():
		Flip()
	
	$AnimatedSprite2D.flip_h = false if direction == 1 else true
	
	velocity.x = SPEED * delta * direction
	
	move_and_slide()

func _on_death_fx_finished() -> void:
	call_deferred("queue_free")

func Flip() -> void:
	direction = -direction
	$RayCast2D.position = -$RayCast2D.position

func _on_player_checker_body_entered(body: Node2D) -> void:
	if body is Player:
		body.Hurt(self)
		velocity.y -= 300

func Hurt() -> void:
	health -= 1
	$AnimationPlayer.play("hit")
	if health == 0:
		$AnimationPlayer.stop()
		$DeathFX.restart()
		$AnimatedSprite2D.hide()
		$AudioStreamPlayer.play()
		
		set_collision_layer_value(1, false)
		
		var newCoin = coinScene.instantiate()
		get_node("/root").get_child(1).call_deferred("add_child", newCoin)
		newCoin.top_level = true
		newCoin.position = position
		newCoin.velocity = Vector2(0, -40)
