extends CharacterBody2D

var isMoving: bool = false
var stopGravity: bool = false
var direction: int = 1
var player: Player
var targetY

@export var health: int = 1
@export var coinScene: PackedScene
## The distance the bat will fall before flying
@export var fallingDistance: int = 100

func _ready() -> void:
	targetY = position.y + fallingDistance

func _process(_delta: float) -> void:
	if $RayCast2D.is_colliding() and $RayCast2D.get_collider() is Player:
		$AnimatedSprite2D.play("wake")
		isMoving = true
		$RayCast2D.enabled = false
		player = $RayCast2D.get_collider()

func _physics_process(delta: float) -> void:
	if isMoving:
		if not is_on_floor() and !stopGravity:
			velocity += get_gravity() * delta
			if position.y > targetY:
				StartMovement()
		elif stopGravity:
			velocity = Vector2(75, 0) * direction
		
		move_and_slide()
		
		if velocity == Vector2.ZERO:
			Turn()
			if !stopGravity:
				StartMovement()

func _on_animated_sprite_2d_animation_finished() -> void:
	if $AnimatedSprite2D.animation == "wake":
		pass

func Turn() -> void:
	direction = -direction
	$AnimatedSprite2D.flip_h = true if direction == -1 else false


func StartMovement() -> void:
	stopGravity = true
	velocity = Vector2(50, 0)
	$AnimatedSprite2D.play("fly")
	if player.position.x > position.x:
		direction = 1
	else:
		direction = -1
		$AnimatedSprite2D.flip_h = true

func Hurt() -> void:
	health -= 1
	$AnimationPlayer.play("hit")
	if health == 0:
		$AnimationPlayer.stop()
		$DeathFX.restart()
		$AnimatedSprite2D.hide()
		$DeathSFX.play()
		
		set_deferred("monitoring", false)
		set_deferred("monitorable", false)
		
		set_collision_layer_value(1, false)
		
		var newCoin = coinScene.instantiate()
		get_node("/root").get_child(1).call_deferred("add_child", newCoin)
		newCoin.top_level = true
		newCoin.position = position
