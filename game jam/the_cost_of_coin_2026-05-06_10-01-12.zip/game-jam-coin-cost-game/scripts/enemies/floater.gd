extends Area2D

## The direction the enemy starts facing
@export_enum("Left", "Right") var startingDir = "Right"
## Scene for the coin bullet. Best not to touch this unless you know what you're doing.
@export var bulletScene: PackedScene
## Speed of the enemy
@export var speed: int = 100

var isDropping: bool = false
var goRight: bool = true
var player: Player
var alreadyFired: bool = false

func _ready() -> void:
	if startingDir == "Left":
		goRight = false

func _physics_process(delta: float) -> void:
	var posMod = 1 if goRight else -1
	
	position.x += speed * delta * posMod
	
	$AnimatedSprite2D.flip_h = !goRight
	
	if $RayCast2D.get_collider() is Player:
		DropCoin($RayCast2D.get_collider())

func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		body.Hurt(self)
	if body is TileMapLayer:
		goRight = !goRight

func DropCoin(detectedPlayer: Player) -> void:
	if !isDropping:
		player = detectedPlayer
		isDropping = true
		$AnimatedSprite2D.play("prepare")
		alreadyFired = true


func _on_animated_sprite_2d_animation_finished() -> void:
	if $AnimatedSprite2D.animation == "prepare":
		$AudioStreamPlayer.play()
		var newCoin = bulletScene.instantiate()
		get_node("/root").get_child(1).call_deferred("add_child", newCoin)
		newCoin.top_level = true
		newCoin.position = position
		newCoin.z_index = -1
		newCoin.isEvil = true
		newCoin.speed = SetAttackAngle()
		$AnimatedSprite2D.play("drop")
	elif $AnimatedSprite2D.animation == "drop":
		isDropping = false

func SetAttackAngle() -> Vector2:
	var posMod = 1 if goRight else -1
	
	if player.velocity.x == 0:
		return Vector2(-10 * posMod, 250)
	elif player.velocity.x < 0 and goRight:
		return Vector2(-220 * posMod, 250)
	else:
		return Vector2(200 * posMod, 250)

func _on_visible_on_screen_enabler_2d_screen_exited() -> void:
	if alreadyFired:
		call_deferred("queue_free")

func Hurt() -> void:
	pass
