extends Node

signal DebugKey1
signal DebugKey2
signal DebugKey3

@export_group("Node locations")
@export var playerNode: Player
@export_category("Audio")
## Mute all music once the scene starts
@export var musicMute: bool
## Mute all SFX once the scene starts
@export var SFXMute: bool
@export_category("Game stuff")
## Sets the player's coin count to 9999 when the scene loads
@export var maxCoins: bool
@export_group("Animation Player")
@export_enum("Key 1", "Key 2", "Key 3") var key = "Key 1"
@export var animName: String
@export var animPlayer: AnimationPlayer

func _ready() -> void:
	AudioServer.set_bus_mute(1, musicMute)
	AudioServer.set_bus_mute(2, SFXMute)
	if maxCoins:
		playerNode.coins = 9999

func _process(_delta: float) -> void:
	if Input.is_action_just_pressed("debug_key1"):
		DebugKey1.emit()
	if Input.is_action_just_pressed("debug_key2"):
		DebugKey2.emit()
	if Input.is_action_just_pressed("debug_key3"):
		DebugKey3.emit()
	
	match key:
		"Key 1":
			if Input.is_action_just_pressed("debug_key1"):
				animPlayer.play(animName)
		"Key 2":
			if Input.is_action_just_pressed("debug_key2"):
				animPlayer.play(animName)
		"Key 3":
			if Input.is_action_just_pressed("debug_key3"):
				animPlayer.play(animName)
