@icon("res://sprites/coin1.png")

extends Area2D

class_name Bullet

## Speed of the bullet when it gets fired
@export var speed: Vector2 = Vector2(450, 0)
## If the bullet is fired by an enemy or not
@export var isEvil: bool = false

func _ready() -> void:
	$Timer.start()

func _physics_process(delta: float) -> void:
	position += speed.rotated(rotation) * delta

func _on_body_entered(body: Node2D) -> void:
	if isEvil:
		if body is Player:
			body.Hurt(self)
			Leave(false)
		if body is TileMapLayer:
			Leave()
	else:
		if body is not Player:
			Leave()

func _on_visible_on_screen_notifier_2d_screen_exited() -> void:
	# If a bullet is no longer visible, probably best to get rid of it.
	Leave()

func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Enemy") and !isEvil:
		Leave()

func _on_timer_timeout() -> void:
	Leave()

## Removes the bullet from the scene. If [code]audio[/code] is [code]true[/code], audio will play and the bullet will wait longer to fully remove itself
func Leave(audio: bool = true) -> void:
	if audio:
		$HitSFX.play()
		$CollisionShape2D.call_deferred("queue_free")
		$Sprite2D.call_deferred("queue_free")
	else:
		call_deferred("queue_free")

func _on_hit_sfx_finished() -> void:
	call_deferred("queue_free")
