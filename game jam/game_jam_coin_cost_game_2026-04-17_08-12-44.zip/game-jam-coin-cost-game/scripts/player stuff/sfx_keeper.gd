extends Node

@export var hit: AudioStream
@export var fire: AudioStream
