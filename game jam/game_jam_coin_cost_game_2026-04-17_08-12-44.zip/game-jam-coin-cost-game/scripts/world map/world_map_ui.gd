extends CanvasLayer

@export var nameNode: Label
@export var detailNode: Label

var okToAnimate: bool = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass


func _on_world_map_call_level_ui(icon: Node2D, appear: bool) -> void:
	nameNode.text = icon.levelName
	if icon.isUnlocked:
		if icon.isBought:
			detailNode.text = "Bought!"
		else:
			detailNode.text = "Level cost: " + str(icon.levelCost)
	else:
		detailNode.text = "Level Locked"
	
	if okToAnimate:
		if appear:
			if $PanelContainer.position.y == 732.0:
				$AnimationPlayer.play("appear")
		else:
			$AnimationPlayer.play("disappear")
