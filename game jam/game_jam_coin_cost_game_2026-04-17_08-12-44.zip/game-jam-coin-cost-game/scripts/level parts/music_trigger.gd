extends Area2D

## Trigger to change what music is currently playing. Make sure to give this a CollisionShape2D to give it shape.
class_name  MusicTrigger

@export_group("New Audio")
@export var newMusicIntro: AudioStream
@export var newMusicLoop: AudioStream
@export var oneShot: bool = false

func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		body.ChangeMusic(newMusicIntro, newMusicLoop)
		if oneShot:
			call_deferred("queue_free")

func _ready() -> void:
	if !body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)
