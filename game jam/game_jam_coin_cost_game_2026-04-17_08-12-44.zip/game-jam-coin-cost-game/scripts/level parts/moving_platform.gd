extends AnimatableBody2D

## The speed of the platform
@export var Speed: float = 10
## The Path2D that the platform will follow.[br]
## [url=https://docs.godotengine.org/en/stable/classes/class_path2d.html#path2d]See the Godot Docs for more info on Path2Ds.[url]
@export var path: Path2D
## If [code]true[/code], the platform will reverse when hitting the end of the Path2D instead of going to the first point
@export var bounce: bool = false
## Which sprite to use
@export_enum("City", "Grass") var sprite = "City"

var PointIndex: int = 0
var direction: int = 1

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	position = path.curve.get_point_position(0)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _physics_process(_delta: float) -> void:
	position = position.move_toward(path.curve.get_point_position(PointIndex), Speed)
	if position == path.curve.get_point_position(PointIndex):
		PointIndex += direction
		if PointIndex >= path.curve.point_count:
			if bounce:
				PointIndex = path.curve.point_count -2
				FlipDir()
			else:
				PointIndex = 0
		if PointIndex == -1:
			PointIndex = 0
			FlipDir()

func FlipDir() -> void:
	direction = -direction
