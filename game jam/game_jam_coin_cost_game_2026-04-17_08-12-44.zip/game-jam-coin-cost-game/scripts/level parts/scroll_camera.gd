extends Camera2D

## Basic camera with modes for tracking. Please instantiate the scene instead of inserting this node.
class_name Camera

## Emits when the FadeIn animation is done
signal DoneWithFadeIn
## Emits when the FadeOut animation is done
signal DoneWithFadeOut

## The initial target for when the scene starts
@export var target: Node2D
## If the camera tracks the target's X position at the start
@export var isTrackingX: bool = true
## If the camera tracks the target's Y position at the start
@export var isTrackingY: bool = true
## Starts the FadeIn animation when the scene loads
@export var startWithFade: bool = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if target == null and (isTrackingX or isTrackingY):
		# Sends an error to the output if you didn't set the target in the inspector.
		printerr("The camera for the currently loaded scene has no target set in the inspector.")
		TrackX(false)
		TrackY(false)
	else:
		if isTrackingX:
			position.x = target.position.x
		if isTrackingY:
			position.y = target.position.y
	if startWithFade:
		FadeOut()

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	if isTrackingX:
		position.x = target.position.x
	if isTrackingY:
		position.y = target.position.y

## Turns off the position smoothing to instantly jump to the target
func SnapToTarget() -> void:
	position_smoothing_enabled = false
	position = target.position
	position_smoothing_enabled = true

## Changes the camera's target
func ChangeTarget(newTarget: Node) -> void:
	target = newTarget

## Changes if the camera is targetting the target X position
func TrackX(track: bool = true) -> void:
	isTrackingX = track

## Changes if the camera is targetting the target Y position
func TrackY(track: bool = true) -> void:
	isTrackingY = track

## Sets the camera's location.
## Ignores the new X position if isTrackingX is enabled, same with Y
func SetLocation(newPosition: Vector2) -> void:
	if !isTrackingX:
		position.x = newPosition.x
	if !isTrackingY:
		position.y = newPosition.y

## Fades in the black overlay, emits the DoneWithFadeIn signal afterwards
func FadeIn() -> void:
	$ColorRect/AnimationPlayer.play("fade_in")

## Fades out the black overlay, emits the DoneWithFadeOut signal afterwards
func FadeOut() -> void:
	$ColorRect/AnimationPlayer.play("fade_out")

func _on_animation_player_animation_finished(anim_name: StringName) -> void:
	if anim_name == "fade_in":
		DoneWithFadeIn.emit()
	if anim_name == "fade_out":
		DoneWithFadeOut.emit()
