extends Player

@export var horizontalInput: int
@export var isJumping: bool
@export var stopAnimation: bool
@export var manualAnimOverride: String

func _ready() -> void:
	pass

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
	
	HandleLandingSignal()
	
	# Handle jump.
	if isJumping and is_on_floor() and !overrideControls:
		velocity.y += JUMP_VELOCITY
		holding_jump = true
	if holding_jump and velocity.y < 0:
		velocity.y -= 15

	# Get the input direction and handle the movement/deceleration.
	var direction = horizontalInput
	if direction:
		velocity.x = direction * SPEED * (1.0 if coins > 0 else coinDroughtSlowness)
		SetFXAndSpriteFlip(direction)
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED / 3)
	
	move_and_slide()
	HandleAnimation()

func _process(_delta: float) -> void:
	if isJumping:
		holding_jump = false
	if stopAnimation:
		$AnimatedSprite2D.animation = manualAnimOverride

func HandleAnimation() -> void:
	if stopAnimation:
		return
	if !is_on_floor():
		$AnimatedSprite2D.animation = "jump"
	elif horizontalInput:
		$AnimatedSprite2D.animation = "walk"
	else:
		$AnimatedSprite2D.animation = "idle"

func SetFXAndSpriteFlip(direction: float) -> void:
	if stopAnimation:
		return
	if direction > 0:
		shouldFlip = false
	if direction < 0:
		shouldFlip = true
	$AnimatedSprite2D.flip_h = shouldFlip
