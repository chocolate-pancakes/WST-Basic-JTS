extends Area2D

var isActive: bool = false

func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		if !isActive:
			body.startPos = position
			$ColorRect.color = Color(0.0, 1.0, 0.0, 1.0)
