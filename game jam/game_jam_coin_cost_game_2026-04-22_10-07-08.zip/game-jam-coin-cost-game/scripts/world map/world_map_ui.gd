extends CanvasLayer

@export var nameNode: Label
@export var detailNode: Label
@export var settingsMenuScene: PackedScene

var okToAnimate: bool = false

var menuSelection: int = 1
var maxSelection: int = 3
const minSelection: int = 1

@onready var resumeText = $MenuContainer/Control/ResumeText
@onready var settingsText = $MenuContainer/Control/SettingsText
@onready var exitText = $MenuContainer/Control/ExitText

@onready var animPlayer = $AnimationPlayer

var navigateMenu = true

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	if Input.is_action_just_pressed("pause"):
		get_tree().paused = !get_tree().paused
		if get_tree().paused:
			menuSelection = 1
			animPlayer.play("openMenu")
		else:
			animPlayer.play("closeMenu")
	
	if get_tree().paused:
		match menuSelection:
			1:
				resumeText.add_theme_color_override("font_color", Global.selectColor)
				settingsText.add_theme_color_override("font_color", Global.textColor)
				exitText.add_theme_color_override("font_color", Global.textColor)
			2:
				resumeText.add_theme_color_override("font_color", Global.textColor)
				settingsText.add_theme_color_override("font_color", Global.selectColor)
				exitText.add_theme_color_override("font_color", Global.textColor)
			3:
				resumeText.add_theme_color_override("font_color", Global.textColor)
				settingsText.add_theme_color_override("font_color", Global.textColor)
				exitText.add_theme_color_override("font_color", Global.selectColor)
		
		if navigateMenu:
			MenuControl()
		
		if Input.is_action_just_pressed("jump") and navigateMenu:
			match menuSelection:
				1:
					Unpause()
				2:
					var settingsMenu = settingsMenuScene.instantiate()
					add_child(settingsMenu)
					navigateMenu = false
				3:
					get_tree().quit()

func _on_world_map_call_level_ui(icon: Node2D, appear: bool) -> void:
	nameNode.text = icon.levelName
	if !icon.isCutscene:
		if icon.isUnlocked:
			if icon.isBought:
				detailNode.text = "Bought!"
			else:
				detailNode.text = "Level cost: " + str(icon.levelCost)
		else:
			detailNode.text = "Level Locked"
	else:
		if icon.isUnlocked:
			detailNode.text = ""
		else:
			detailNode.text = "Locked"
	
	if okToAnimate:
		if appear:
			if $DetailsContainer.position.y == 732.0:
				$AnimationPlayer.play("appear")
		else:
			$AnimationPlayer.play("disappear")

func MenuControl(menuItems: int = 3) -> void:
	maxSelection = menuItems
	if Input.is_action_just_pressed("move_down"):
		menuSelection += 1
		if menuSelection > maxSelection:
			menuSelection = 1
	if Input.is_action_just_pressed("move_up"):
		menuSelection -= 1
		if menuSelection < minSelection:
			menuSelection = maxSelection

func Unpause() -> void:
	animPlayer.play("closeMenu")
	get_tree().paused = false

func RegainControl() -> void:
	navigateMenu = true
