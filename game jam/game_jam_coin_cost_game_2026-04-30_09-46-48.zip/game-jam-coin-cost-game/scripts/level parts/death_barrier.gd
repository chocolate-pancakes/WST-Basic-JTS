extends Area2D

func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		body.position = body.startPos
		body.Hurt(self)
		body.velocity = Vector2.ZERO
