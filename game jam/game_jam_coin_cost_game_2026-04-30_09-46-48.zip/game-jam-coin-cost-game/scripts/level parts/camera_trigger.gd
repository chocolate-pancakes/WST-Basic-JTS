extends Area2D

## Trigger for adjusting values for the camera. Make sure to give this a CollisionShape2D to give it shape.
class_name CameraTrigger

## The ScrollCamera node
@export var CameraNode: Camera
## Direction the trigger is facing.[br]
## If the player leaves the trigger's bounds in the opposite direction of this value, the trigger will instead set the values to their old values obtained with BackupOldValues()
@export_enum("Up", "Down", "Left", "Right") var direction = "Up"
@export_group("Overrides")
## Sets if the trigger will change the camera's TrackX variable
@export var changeTrackX: bool
## Sets if the trigger will change the camera's TrackY variable
@export var changeTrackY: bool
## Sets if the trigger will change the camera's position
@export var willChangePos: bool
## Sets if the trigger will change the camera's target
@export var willChangeTarget: bool
@export_group("New values")
## The new value for the camera's TrackX variable.[br]
## Ignore if ChangeTrackX is false.
@export var willTrackX: bool
## The new value for the camera's TrackY variable.[br]
## Ignore if ChangeTrackY is false.
@export var willTrackY: bool
## The new value for the camera's position.[br]
## Ignore if WillChangePos is false.
@export var newPos: Vector2
## The new target for the camera to track.[br]
## Ignore if WillChangeTarget is false.
@export var newTarget: Node

## The camera's old target
var oldTarget
## The camera's old position
var oldPos
## The camera's old TrackX value
var oldTrackX
## The camera's old TrackY value
var oldTrackY

## Whenever the trigger has already gotten the old values of the camera
var hasGottenOld: bool = false

func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		BackupOldValues()
		
		if changeTrackX:
			CameraNode.TrackX(willTrackX)
		if changeTrackY:
			CameraNode.TrackY(willTrackY)
		
		if willChangePos:
			CameraNode.SetLocation(newPos)
		
		if willChangeTarget:
			if newTarget is Node:
				CameraNode.ChangeTarget(newTarget)
			else:
				printerr("The camera trigger that was entered was supposed to change the camera's target, but no new target was set in the inspector.")

## If the trigger hasn't already, it'll get the current values of the camera before it changes them.
func BackupOldValues() -> void:
	if !hasGottenOld:
		oldPos = CameraNode.position
		oldTarget = CameraNode.target
		oldTrackX = CameraNode.isTrackingX
		oldTrackY = CameraNode.isTrackingY
		hasGottenOld = true

func _on_body_exited(body: Node2D) -> void:
	if body is Player:
		match direction:
			"Up":
				if position.y < body.position.y:
					RestoreValues()
			"Down":
				if position.y > body.position.y:
					RestoreValues()
			"Left":
				if position.x < body.position.x:
					RestoreValues()
			"Right":
				if position.x > body.position.x:
					RestoreValues()

## Restores the old values the camera had before the trigger changed them if the player went back before they fully left the trigger.
func RestoreValues() -> void:
	CameraNode.TrackX(oldTrackX)
	CameraNode.TrackY(oldTrackY)
	CameraNode.ChangeTarget(oldTarget)
	CameraNode.SetLocation(oldPos)

func _ready() -> void:
	if !body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)
	if !body_exited.is_connected(_on_body_exited):
		body_exited.connect(_on_body_exited)
