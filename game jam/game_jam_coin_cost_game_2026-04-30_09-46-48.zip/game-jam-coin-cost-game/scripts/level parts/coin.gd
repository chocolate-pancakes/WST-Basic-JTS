extends Area2D

## What speeds the coin will shoot off at when it's added to the scene
@export var velocity: Vector2 = Vector2.ZERO
## The baseline speed that is mutiplied with the velocity
@export var SPEED = 100.0

func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		$AudioStreamPlayer.play()
		$CollisionShape2D.call_deferred("queue_free")
		$Sprite2D.queue_free()
		body.coins += 1
		body.gainedHere += 1

func _process(delta: float) -> void:
	position += velocity * delta
	velocity = velocity.move_toward(Vector2.ZERO, delta * 50)

func _on_audio_stream_player_finished() -> void:
	call_deferred("queue_free")
