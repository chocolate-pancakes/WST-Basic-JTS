extends Area2D

@export var textLine1: String
@export var textLine2: String

func _ready() -> void:
	if textLine2 == "":
		$Label.text = textLine1
	else:
		$Label.text = textLine1 + "\n" + textLine2
	$Label.hide()

func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		$Label.show()

func _on_body_exited(body: Node2D) -> void:
	if body is Player:
		$Label.hide()
