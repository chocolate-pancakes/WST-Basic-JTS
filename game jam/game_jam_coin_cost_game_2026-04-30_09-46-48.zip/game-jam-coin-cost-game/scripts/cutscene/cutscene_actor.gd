extends CharacterBody2D

## Actor to use in cutscenes
##
## Base class to use for cutscene actors. To give collision, add a CollisionShape2D named "Collider" and add an AnimatedSprite2D named "Sprite" for animation. [br][br]
## Add [code]horizontalMovement[/code], [code]verticalMovement[/code], and [code]jumping[/code] as keyframes to an AnimationPlayer to give animation.
class_name  CutsceneActor

## Whenever this actor will move around on the ground like the player, or float around without being bound by gravity
@export_enum("Gravity", "Floating") var movementMode = "Gravity"
@export_category("Keyframable actions")
## Input for the actor's horizontal movement.
@export var horizontalMovement: int
## Input for the actor's vertical movement. [br]
## Ignore if [code]movementMode[/code] is set to Gravity.
@export var verticalMovement: int
## Input for the actor's jump. [br]
## Ignore if [code]movementMode[/code] is set to Floating.
@export var jumping: bool
## Set to true in the animation to forcibly play the sprite's current animation.[br]
## It will instantly be set back to false afterwards.
@export var forcePlayAnim: bool
@export_category("Sprite Names")
## Name for the idle animation for when no movement is being made.
@export var idle: String = "idle"
## Name for the moving animation for when the actor is moving on the ground, or doing any movement in Floating mode.
@export var walking: String = "movement"
## Name for the jumping animation for when the actor is jumping.[br]
## Ignore if [code]movementMode[/code] is set to Floating.
@export var jump: String = "jump"

var holding_jump: bool = false
## If you want to override the flipping, have this set to true.[br]
## It won't have any effect if [code]horizontalMovement[/code] isn't zero.
@export var shouldFlip: bool = false

@export var SPEED = 200.0
@export var JUMP_VELOCITY = -500.0

func _ready() -> void:
	if $Collider == null:
		printerr(str(self) + " couldn't find their collider! \nPlease make sure it is called \"Collider\" and a child of this node!")
	if $Sprite == null:
		printerr(str(self) + " couldn't find their sprite! \nPlease make sure it is called \"Sprite\" and a child of this node! ")
	
	if movementMode == "Floating":
		motion_mode = CharacterBody2D.MOTION_MODE_FLOATING

func _process(_delta: float) -> void:
	if jumping:
		holding_jump = false
	if horizontalMovement > 0:
		shouldFlip = false
	if horizontalMovement < 0:
		shouldFlip = true
	
	if forcePlayAnim:
		$Sprite.play()
		forcePlayAnim = false

func _physics_process(delta: float) -> void:
	match movementMode:
		"Gravity":
			# Add the gravity.
			if not is_on_floor():
				velocity += get_gravity() * delta
			
			# Handle jump.
			if jumping and is_on_floor():
				velocity.y += JUMP_VELOCITY
				holding_jump = true
			if holding_jump and velocity.y < 0:
				velocity.y -= 15

			# Get the input direction and handle the movement/deceleration.
			var direction = horizontalMovement
			if direction:
				velocity.x = horizontalMovement * SPEED
			else:
				velocity.x = move_toward(velocity.x, 0, SPEED / 3)
			
			move_and_slide()
			HandleAnimation()
		"Floating":
			if horizontalMovement or verticalMovement:
				velocity = Vector2(horizontalMovement, verticalMovement).normalized() * SPEED
			else:
				velocity.x = move_toward(velocity.x, 0, SPEED / 3)
				velocity.y = move_toward(velocity.y, 0, SPEED / 3)
			
			move_and_slide()
			HandleAnimation()

func HandleAnimation() -> void:
	match movementMode:
		"Gravity":
			if !is_on_floor():
				$Sprite.animation = jump
			elif horizontalMovement:
				$Sprite.animation = walking
			else:
				$Sprite.animation = idle
		"Floating":
			if horizontalMovement or verticalMovement:
				$Sprite.animation = walking
			else:
				$Sprite.animation = idle
	$Sprite.flip_h = shouldFlip
