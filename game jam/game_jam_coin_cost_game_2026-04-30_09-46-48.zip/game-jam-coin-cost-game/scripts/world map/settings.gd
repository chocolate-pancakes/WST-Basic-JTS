extends Control

signal settingsExit

var menuSelection: int = 1
var maxSelection: int = 3
const minSelection: int = 1

@onready var music = $PanelContainer/Control/MusicAdjust
@onready var SFX = $PanelContainer/Control/SFXAdjust
@onready var window = $PanelContainer/Control/WindowAdjust
@onready var apply = $PanelContainer/Control/ApplyText
@onready var exit = $PanelContainer/Control/ExitText

var windowModes = [Window.MODE_WINDOWED, Window.MODE_MAXIMIZED, Window.MODE_EXCLUSIVE_FULLSCREEN, Window.MODE_FULLSCREEN]
var windowModesText = ["Windowed", "Maximized", "Exclusive fullscreen", "Fullscreen"]
var currentWindowMode: int = 0

var musicVolume: int = 10
var SFXVolume: int = 10

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	LoadSettings()
	music.text = "Music volume: " + str(musicVolume * 10) + "%"
	SFX.text = "SFX volume: " + str(SFXVolume * 10) + "%"
	window.text = "Window mode: " + windowModesText[currentWindowMode]
	
	if get_parent() != CanvasLayer:
		settingsExit.connect(get_parent().RegainControl)
	$AnimationPlayer.play("enter")

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	MenuControl(5)
	
	match menuSelection:
		1:
			music.add_theme_color_override("font_color", Global.selectColor)
			SFX.add_theme_color_override("font_color", Global.textColor)
			window.add_theme_color_override("font_color", Global.textColor)
			apply.add_theme_color_override("font_color", Global.textColor)
			exit.add_theme_color_override("font_color", Global.textColor)
		2:
			music.add_theme_color_override("font_color", Global.textColor)
			SFX.add_theme_color_override("font_color", Global.selectColor)
			window.add_theme_color_override("font_color", Global.textColor)
			apply.add_theme_color_override("font_color", Global.textColor)
			exit.add_theme_color_override("font_color", Global.textColor)
		3:
			music.add_theme_color_override("font_color", Global.textColor)
			SFX.add_theme_color_override("font_color", Global.textColor)
			window.add_theme_color_override("font_color", Global.selectColor)
			apply.add_theme_color_override("font_color", Global.textColor)
			exit.add_theme_color_override("font_color", Global.textColor)
		4:
			music.add_theme_color_override("font_color", Global.textColor)
			SFX.add_theme_color_override("font_color", Global.textColor)
			window.add_theme_color_override("font_color", Global.textColor)
			apply.add_theme_color_override("font_color", Global.selectColor)
			exit.add_theme_color_override("font_color", Global.textColor)
		5:
			music.add_theme_color_override("font_color", Global.textColor)
			SFX.add_theme_color_override("font_color", Global.textColor)
			window.add_theme_color_override("font_color", Global.textColor)
			apply.add_theme_color_override("font_color", Global.textColor)
			exit.add_theme_color_override("font_color", Global.selectColor)
	
	if Input.is_action_just_pressed("jump") or Input.is_action_just_pressed("move_right"):
		$AudioMove.play()
		match  menuSelection:
			1:
				musicVolume += 1
				if musicVolume > 10:
					musicVolume = 0
				music.text = "Music volume: " + str(musicVolume * 10) + "%"
			2:
				SFXVolume += 1
				if SFXVolume > 10:
					SFXVolume = 0
				SFX.text = "SFX volume: " + str(SFXVolume * 10) + "%"
			3:
				currentWindowMode += 1
				if currentWindowMode > 3:
					currentWindowMode = 0
				window.text = "Window mode: " + windowModesText[currentWindowMode]
			4: 
				AudioServer.set_bus_volume_linear(1, float(musicVolume) / 10)
				AudioServer.set_bus_volume_linear(2, float(SFXVolume) / 10)
				DisplayServer.window_set_mode(windowModes[currentWindowMode])
				SaveSettings()
				$AudioMove.stop()
				$AudioSelect.play()
			5:
				settingsExit.emit()
				$AnimationPlayer.play("leave")
				$AudioMove.stop()
				$AudioCancel.play()
	
	if Input.is_action_just_pressed("move_left"):
		$AudioMove.play()
		match  menuSelection:
			1:
				musicVolume -= 1
				if musicVolume < 0:
					musicVolume = 10
				music.text = "Music volume: " + str(musicVolume * 10) + "%"
			2:
				SFXVolume -= 1
				if SFXVolume < 0:
					SFXVolume = 10
				SFX.text = "SFX volume: " + str(SFXVolume * 10) + "%"
			3:
				currentWindowMode -= 1
				if currentWindowMode < 0:
					currentWindowMode = 3
				window.text = "Window mode: " + windowModesText[currentWindowMode]
			4: 
				pass
			5:
				pass
	
	if Input.is_action_just_pressed("attack"):
		settingsExit.emit()
		$AnimationPlayer.play("leave")
		$AudioCancel.play()

func MenuControl(menuItems: int = 3) -> void:
	maxSelection = menuItems
	if Input.is_action_just_pressed("move_down"):
		$AudioMove.play()
		menuSelection += 1
		if menuSelection > maxSelection:
			menuSelection = 1
	if Input.is_action_just_pressed("move_up"):
		$AudioMove.play()
		menuSelection -= 1
		if menuSelection < minSelection:
			menuSelection = maxSelection

func SaveSettings() -> void:
	var settingsFile = ConfigFile.new()
	settingsFile.set_value("Settings", "Music Volume", musicVolume)
	settingsFile.set_value("Settings", "SFX Volume", SFXVolume)
	settingsFile.set_value("Settings", "Window mode", currentWindowMode)
	settingsFile.set_value("First Boot", "First Boot", false)
	
	settingsFile.save("user://settings.sav")

func LoadSettings() -> void:
	var settingsFile = ConfigFile.new()
	var err = settingsFile.load("user://settings.sav")
	if err != OK:
		pass
	
	musicVolume = settingsFile.get_value("Settings", "Music Volume", 10)
	SFXVolume = settingsFile.get_value("Settings", "SFX Volume", 10)
	currentWindowMode = settingsFile.get_value("Settings", "Window mode", 0)

func _on_animation_player_animation_finished(anim_name: StringName) -> void:
	if anim_name == "leave":
		call_deferred("queue_free")
