extends Node2D

var menuSelection: int = 1
var maxSelection: int = 3
const minSelection: int = 1

@onready var Continue = $Control/Continue
@onready var New = $Control/New
@onready var Settings = $Control/Settings
@onready var Exit = $Control/Exit
@export var settingsMenuScene: PackedScene

var fileExists: bool
var canControl: bool = true
var inConfirm: bool = false
var chances: int = 3

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if Global.firstBoot:
		get_tree().call_deferred("change_scene_to_file", "res://scenes/help.tscn")
		#change_scene_to_file("res://scenes/help.tscn")
	fileExists = FileAccess.file_exists("user://game.sav") and FileAccess.file_exists("user://levels.sav")
	if !fileExists:
		Continue.text = "Continue Game (no game to continue!)"
		menuSelection = 2


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	if canControl:
		MenuControl(4)
	if !inConfirm:
		match menuSelection:
			1:
				Continue.add_theme_color_override("font_color", Global.selectColor)
				New.add_theme_color_override("font_color", Global.textColor)
				Settings.add_theme_color_override("font_color", Global.textColor)
				Exit.add_theme_color_override("font_color", Global.textColor)
			2:
				Continue.add_theme_color_override("font_color", Global.textColor)
				New.add_theme_color_override("font_color", Global.selectColor)
				Settings.add_theme_color_override("font_color", Global.textColor)
				Exit.add_theme_color_override("font_color", Global.textColor)
			3:
				Continue.add_theme_color_override("font_color", Global.textColor)
				New.add_theme_color_override("font_color", Global.textColor)
				Settings.add_theme_color_override("font_color", Global.selectColor)
				Exit.add_theme_color_override("font_color", Global.textColor)
			4:
				Continue.add_theme_color_override("font_color", Global.textColor)
				New.add_theme_color_override("font_color", Global.textColor)
				Settings.add_theme_color_override("font_color", Global.textColor)
				Exit.add_theme_color_override("font_color", Global.selectColor)
	
	if Input.is_action_just_pressed("jump") and canControl:
		$AudioSelect.play()
		canControl = false
		match menuSelection:
			1:
				$ScrollCamera.DoneWithFadeIn.connect(StartGame)
				$ScrollCamera.FadeIn()
			2:
				if fileExists:
					inConfirm = true
					chances = 3
					$AnimationPlayer.play("warnAppear")
				else:
					$ScrollCamera.DoneWithFadeIn.connect(StartGame)
					$ScrollCamera.FadeIn()
			3:
				var settingsMenu = settingsMenuScene.instantiate()
				add_child(settingsMenu)
			4:
				$ScrollCamera.DoneWithFadeIn.connect(ExitGame)
				$ScrollCamera.FadeIn()
	
	if inConfirm and !$AnimationPlayer.is_playing():
		MenuControl(2)
		match menuSelection:
			1:
				$Panel/Confirm.add_theme_color_override("font_color", Global.selectColor)
				$Panel/No.add_theme_color_override("font_color", Global.textColor)
			2:
				$Panel/Confirm.add_theme_color_override("font_color", Global.textColor)
				$Panel/No.add_theme_color_override("font_color", Global.selectColor)
		
		if Input.is_action_just_pressed("jump"):
			match menuSelection:
				1:
					menuSelection = 1
					chances -= 1
					match chances:
						2:
							$Panel/WarningText.text = "Are you sure? Data can not be recovered."
						1:
							$Panel/WarningText.text = "Last chance! You will start from square one again!"
							$Panel/Confirm.text = "Yes! Enough already!"
							$Panel/No.text = "...I changed my mind."
						0:
							DirAccess.remove_absolute("user://game.sav")
							DirAccess.remove_absolute("user://levels.sav")
							inConfirm = false
							$AnimationPlayer.play("warnDisappear")
							$ScrollCamera.DoneWithFadeIn.connect(StartGame)
							$ScrollCamera.FadeIn()
				2:
					inConfirm = false
					canControl = true
					chances = 3
					$AnimationPlayer.play("warnDisappear")
					$Panel/Confirm.text = "Yes"
					$Panel/No.text = "No"

func MenuControl(menuItems: int = 3) -> void:
	maxSelection = menuItems
	if Input.is_action_just_pressed("move_down"):
		$AudioMove.play()
		menuSelection += 1
		if menuSelection > maxSelection:
			menuSelection = 1
	if Input.is_action_just_pressed("move_up"):
		$AudioMove.play()
		menuSelection -= 1
		if menuSelection < minSelection:
			menuSelection = maxSelection

func ExitGame() -> void:
	get_tree().quit()

func StartGame() -> void:
	get_tree().change_scene_to_file("res://scenes/world map/world_map.tscn")

func RegainControl() -> void:
	canControl = true
