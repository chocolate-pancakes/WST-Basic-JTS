extends CanvasLayer

@export var Boss: Node2D
var maxHealth

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if Boss.health == null:
		printerr("Please set the BossUI's boss variable.")
	maxHealth = Boss.health


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	if Boss != null:
		$ProgressBar.value = (float(Boss.health) / float(maxHealth)) * 100
