extends Node

var currentLevelIndex: int = 1
var newCoinAmount: int
var doLevelUnlock: bool = false
var totalLoss: int = 0

var musicVolume
var SFXVolume
var currentWindowMode
var firstBoot: bool

var textColor = Color("ffffff")
var selectColor = Color("ffff00")

# This script is an autoload, it's loaded at the start of runtime and contains some functions and variables any script can access with Global.attribute_name
# Please do not attach this script to any node.

func LevelEnd() -> void:
	doLevelUnlock = true
	currentLevelIndex -= 1
	get_tree().change_scene_to_file("res://scenes/world map/world_map.tscn")

func LoadLevel(level: PackedScene) -> void:
	get_tree().change_scene_to_packed(level)

func _ready() -> void:
	var windowModes = [Window.MODE_WINDOWED, Window.MODE_MAXIMIZED, Window.MODE_EXCLUSIVE_FULLSCREEN, Window.MODE_FULLSCREEN]
	DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_SHARP_CORNERS, true)
	var settingsFile = ConfigFile.new()
	settingsFile.load("user://settings.sav")
	
	musicVolume = settingsFile.get_value("Settings", "Music Volume", 10)
	SFXVolume = settingsFile.get_value("Settings", "SFX Volume", 10)
	currentWindowMode = settingsFile.get_value("Settings", "Window mode", 0)
	firstBoot = settingsFile.get_value("First Boot", "First Boot", true)
	
	AudioServer.set_bus_volume_linear(1, float(musicVolume) / 10)
	AudioServer.set_bus_volume_linear(2, float(SFXVolume) / 10)
	DisplayServer.window_set_mode(windowModes[currentWindowMode])

func ApplyFirstBoot() -> void:
	var settingsFile = ConfigFile.new()
	
	settingsFile.set_value("Settings", "Music Volume", musicVolume)
	settingsFile.set_value("Settings", "SFX Volume", SFXVolume)
	settingsFile.set_value("Settings", "Window mode", currentWindowMode)
	settingsFile.set_value("First Boot", "First Boot", false)
	
	settingsFile.save("user://settings.sav")
