@icon("res://sprites/player/Player_Idle.png")

extends CharacterBody2D
## The player node. Please instantiate the player scene instead of inserting this node.

# class_name gives the node the script is attach to a unique identifier any script can acess, think how you can set a variable's type to a script name in Unity
class_name Player

## Emitted when the player lands
signal onLanding
signal onDeath

# Remember: @export is GDScript's [Serializefield]
# @export_group also places each variable under it in a nice, collapsable section in the inspector
# PS you don't always have to tell Godot what type a variable is, but if you have an @export and don't have an initial value Godot will get mad at you
# and even if it's not an @export, I think if you try adding stuff to an uninitialized variable, Godot will throw an error for trying to add to a nil value
@export_group("Movement")
## The player's speed
@export var SPEED = 200.0
## The inital velocity when the player jumps
@export var JUMP_VELOCITY = -400.0
## Multiplier applied to the speed variable when the player has 0 coins
@export var coinDroughtSlowness: float = 0.75
@export_group("Coin losses")
## Coins lost when the WalkCoinLose timer finishes
@export var walkLoss: int
## Coins lost when the player jumps
@export var jumpLoss: int
@export_group("Scene references (maybe don't touch these)")
## The bullet scene. [b]PLEASE DO NOT CHANGE THIS.[/b]
@export var bulletScene: PackedScene
@export_group("Music")
## The music that will start playing when the scene starts
@export var startingMusicIntro: AudioStreamMP3
## Once the intro is done playing, the loop part will start looping, if there is one.
@export var startingMusicLoop: AudioStreamMP3

## The coins the player has
var coins: int = 500
## If the jump button is held instead of tapped
var holding_jump: bool = false
## The starting position of the player, set when the player enters the scene
var startPos: Vector2
## Amount of coins lost in the level
var lostHere: int = 0
## Amount of coins got in the level
var gainedHere: int = 0

## If the sprite and particles should flip
var shouldFlip: bool = false
## When [code]true[/code], the player can't move or jump
var overrideControls: bool = false
## Whenever [code]overrideControls[/code] was set to true from the player getting hit
var wasHit: bool = false
## When [code]true[/code], no animation will automatically play
var overrideAnimation: bool = false
## When [code]true[/code], the x velocity will not try going back to zero
var slipAround: bool = false

## Whenever the player was in the air last frame
var areialLastFrame: bool = false

@onready var SFX = $SFXKeeper

func _ready() -> void:
	startPos = position
	$AnimatedSprite2D.play()
	
	var gameFile = ConfigFile.new()
	gameFile.load("user://game.sav")
	
	coins = gameFile.get_value("Game", "Coins", 100)
	
	if startingMusicIntro != null:
		$MusicPlayer.stream = startingMusicIntro
		$MusicPlayer.play()

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
	
	HandleLandingSignal()
	
	# Handle jump.
	if Input.is_action_just_pressed("jump") and is_on_floor() and !overrideControls:
		velocity.y += JUMP_VELOCITY
		holding_jump = true
		LoseCoins(jumpLoss, true)
	if holding_jump and velocity.y < 0:
		velocity.y -= 15

	# Get the input direction and handle the movement/deceleration.
	if !overrideControls:
		var direction = round(Input.get_axis("move_left", "move_right"))
		if direction:
			# Sets the velocity, flips the sprite and particle direction if needed, then starts the WalkCoinLose timer if it isn't already running
			velocity.x = direction * SPEED * (1.0 if coins > 0 else coinDroughtSlowness)
			SetFXAndSpriteFlip(direction)
			if $WalkCoinLose.is_stopped(): $WalkCoinLose.start()
		else:
			# Move the x velocity towards 0, and stop the WalkCoinLoseTimer
			velocity.x = move_toward(velocity.x, 0, SPEED / 3)
			$WalkCoinLose.stop()
	else:
		if !wasHit:
			if !slipAround:
				velocity.x = move_toward(velocity.x, 0, SPEED / 3)
			$WalkCoinLose.stop()
	
	# move_and_slide() is a built-in function for CharacterBody2Ds that has it perform physics
	move_and_slide()
	HandleAnimation()
	
	if is_on_floor() and wasHit:
		overrideControls = false
		wasHit = false
	
	for i in get_slide_collision_count():
		var collider = get_slide_collision(i)
		if collider.get_collider().is_in_group("Enemy"):
			Hurt(collider.get_collider())

func _process(_delta: float) -> void:
	# Just makes it so when the jump button is released, holding_jump is false
	if Input.is_action_just_released("jump"):
		holding_jump = false

func _on_walk_coin_lose_timeout() -> void:
	# The WalkCoinLose child node calls this function every time it finishes
	LoseCoins(walkLoss)

## Method to call when you take coins from the player. [code]loss[/code] is the amount lost, and [code]doEffect[/code] is whenever to do the particle effect for losing coins.
func LoseCoins(loss: int, doEffect: bool = true) -> void:
	if coins > 0:
		coins -= loss
		lostHere += loss
		Global.totalLoss += loss
		if doEffect:
			if !$CoinFX1.emitting:
				$CoinFX1.amount = loss
				$CoinFX1.restart()
			elif !$CoinFX2.emitting:
				$CoinFX2.amount = loss
				$CoinFX2.restart()
			else:
				$CoinFX3.amount = loss
				$CoinFX3.restart()

## Method to handle the flipping of the sprite and particles
func SetFXAndSpriteFlip(direction: float) -> void:
	# This isn't just shouldFlip = direction < 0 since the sprite needs to stay whatever direction it was facing when you stop moving
	if direction > 0:
		shouldFlip = false
	if direction < 0:
		shouldFlip = true
	
	$AnimatedSprite2D.flip_h = shouldFlip
	# Flips the CoinFX to face the opposite way as well
	$CoinFX1.direction = Vector2(-1, -1) if !shouldFlip else Vector2(1, -1)
	$CoinFX2.direction = Vector2(-1, -1) if !shouldFlip else Vector2(1, -1)
	$CoinFX3.direction = Vector2(-1, -1) if !shouldFlip else Vector2(1, -1)
	# Yes, Godot will let you put if then statements in values

## Method to handle the sprite's animation
func HandleAnimation() -> void:
	if overrideAnimation:
		return
	var currentlyFiring = !$FireSpriteKeep.is_stopped()
	if currentlyFiring:
		currentlyFiring = "_fire"
	else:
		currentlyFiring = ""
	
	if overrideControls and wasHit:
		$AnimatedSprite2D.animation = "hurt"
	elif !is_on_floor():
		$AnimatedSprite2D.animation = "jump" + currentlyFiring
	elif round(Input.get_axis("move_left", "move_right")):
		$AnimatedSprite2D.animation = "walk" + currentlyFiring
	else:
		$AnimatedSprite2D.animation = "idle" + currentlyFiring

## Method to handle getting hurt
func Hurt(enemy: Node2D) -> void:
	if $IFrame.is_stopped() and !overrideControls:
		PlaySFX(SFX.hit)
		velocity.y = JUMP_VELOCITY
		var knockbackDir = 1 if position > enemy.position else -1
		velocity.x = SPEED * knockbackDir
		overrideControls = true
		wasHit = true
		if coins <= 0:
			GameOver()
		LoseCoins(10)
		$IFrame.start()

## Plays an animation if [code]overrideAnimation[/code] is true
func PlayAnimation(animName: String):
	$AnimatedSprite2D.play(animName)

## Method to handle emiting the [code]onLanding[/code] signal
func HandleLandingSignal() -> void:
	if !is_on_floor():
		areialLastFrame = true
	if is_on_floor() and areialLastFrame:
		areialLastFrame = false
		onLanding.emit()

func _on_music_player_finished() -> void:
	$MusicPlayer.stream = startingMusicLoop
	$MusicPlayer.play()

func ChangeMusic(intro: AudioStream = null, loop: AudioStream = null):	
	if intro == null and loop == null:
		$MusicPlayer.stop()
	
	if intro == null and loop != null:
		$MusicPlayer.stream = loop
		$MusicPlayer.play()

func PlaySFX(sfx: AudioStream):
	$SFXPlayer.stream = sfx
	$SFXPlayer.play()

func GameOver() -> void:
	ChangeMusic()
	Global.newCoinAmount = 250
	onDeath.emit()
	overrideAnimation = true
	PlayAnimation("idle")
	Engine.time_scale = 0.1
	$GameOverTimer.start()

func _on_game_over_timer_timeout() -> void:
	Engine.time_scale = 1
	Global.LevelEnd()
