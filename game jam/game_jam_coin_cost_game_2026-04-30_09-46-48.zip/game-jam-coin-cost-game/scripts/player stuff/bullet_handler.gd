extends Node

@onready var player: Player = get_parent()
@export var FireSpriteKeepTimer: Timer

func _physics_process(_delta: float) -> void:
	if !player.overrideControls:
		if Input.is_action_just_pressed("attack"):
			FireBullet(deg_to_rad(0) if !get_parent().get_child(0).flip_h else deg_to_rad(180))
		
		#if Input.is_action_just_pressed("alt_attack") and !get_parent().is_on_floor():
		#	FireBullet(deg_to_rad(90))

func FireBullet(angle: float) -> void:
	if $FireCooldown.is_stopped() and player.coins > 0:
		var newBullet = get_parent().bulletScene.instantiate()
		add_child(newBullet)
		
		newBullet.top_level = true
		newBullet.position = get_parent().position
		newBullet.rotation = angle
		
		player.PlaySFX(player.SFX.fire)
		
		player.LoseCoins(1, false)
		$FireCooldown.start()
		FireSpriteKeepTimer.start()
