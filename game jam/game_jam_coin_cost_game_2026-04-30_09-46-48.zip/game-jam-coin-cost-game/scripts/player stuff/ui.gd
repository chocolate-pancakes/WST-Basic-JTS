extends CanvasLayer

## The player node in the scene
@export var playerNode: Player
## The camera node in the scene
@export var camera: Camera

@onready var resume = $PausePanel/ResumeText
@onready var restart = $PausePanel/RestartText
@onready var exit = $PausePanel/ExitText

@onready var world = $WinPanel/WorldMap
@onready var replay = $WinPanel/ReplayLevel

var menuSelection: int = 1
var maxSelection: int = 3
const minSelection: int = 1

var levelOver: bool = false
var winNode: Area2D

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	$AnimationPlayer.play("coinCounterCall")
	if camera == null:
		printerr("Please set the camera variable for the UI in the inspector.")
	if playerNode == null:
		printerr("Please set the playerNode variable for the UI in the inspector.")


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	$CoinCounter.text = "Coins: " + str(playerNode.coins)
	if Input.is_action_just_pressed("pause") and !levelOver and !$AnimationPlayer.is_playing():
		get_tree().paused = !get_tree().paused
		if get_tree().paused:
			menuSelection = 1
			$AnimationPlayer.play("pause")
		else:
			$AnimationPlayer.play("unpause")
	
	if get_tree().paused:
		match menuSelection:
			1:
				resume.add_theme_color_override("font_color", Global.selectColor)
				restart.add_theme_color_override("font_color", Global.textColor)
				exit.add_theme_color_override("font_color", Global.textColor)
			2:
				resume.add_theme_color_override("font_color", Global.textColor)
				restart.add_theme_color_override("font_color", Global.selectColor)
				exit.add_theme_color_override("font_color", Global.textColor)
			3:
				resume.add_theme_color_override("font_color", Global.textColor)
				restart.add_theme_color_override("font_color", Global.textColor)
				exit.add_theme_color_override("font_color", Global.selectColor)
		
		MenuControl()
		
		if Input.is_action_just_pressed("jump"):
			$AudioSelect.play()
			match menuSelection:
				1:
					Unpause()
				2:
					camera.DoneWithFadeIn.connect(RestartLevel)
					camera.FadeIn()
					Unpause()
				3:
					camera.DoneWithFadeIn.connect(ExitLevel)
					camera.FadeIn()
					Unpause()
	if levelOver:
		match menuSelection:
			1:
				world.add_theme_color_override("font_color", Color("#ffff00"))
				replay.add_theme_color_override("font_color", Color("#ffffff"))
			2:
				world.add_theme_color_override("font_color", Color("#ffffff"))
				replay.add_theme_color_override("font_color", Color("#ffff00"))
		
		MenuControl(2)
		
		if Input.is_action_just_pressed("jump"):
			$AudioSelect.play()
			match menuSelection:
				1:
					$AnimationPlayer.play("winUIClose")
					camera.FadeIn()
				2:
					camera.DoneWithFadeIn.disconnect(winNode.EndLevel)
					camera.DoneWithFadeIn.connect(RestartLevel)
					Global.newCoinAmount = winNode.player.coins
					$AnimationPlayer.play("winUIClose")
					camera.FadeIn()

func RestartLevel() -> void:
	get_tree().reload_current_scene()

func ExitLevel() -> void:
	get_tree().call_deferred("unload_current_scene")
	get_tree().change_scene_to_file("res://scenes/world map/world_map.tscn")

func Unpause() -> void:
	$AnimationPlayer.play("unpause")
	get_tree().paused = false

func MenuControl(menuItems: int = 3) -> void:
	maxSelection = menuItems
	if Input.is_action_just_pressed("move_down"):
		$AudioMove.play()
		menuSelection += 1
		if menuSelection > maxSelection:
			menuSelection = 1
	if Input.is_action_just_pressed("move_up"):
		$AudioMove.play()
		menuSelection -= 1
		if menuSelection < minSelection:
			menuSelection = maxSelection

func WinLevelUI(winSpot: Area2D) -> void:
	winNode = winSpot
	levelOver = true
	$WinPanel/LossText.text = "You lost " + str(playerNode.lostHere) + " coins."
	$WinPanel/GainText.text = "You gained " + str(playerNode.gainedHere) + " coins."
	$AnimationPlayer.play("winUIOpen")

func LoseLevel() -> void:
	$GameOverText.show()
